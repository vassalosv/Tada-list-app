# TaDa v0.1.0 — start here

## Web application

1. Install a patched Node 22 LTS release (22.17+).
2. In this extracted directory run `npm ci` and `npm start`.
3. Open http://localhost:3001 and create your account.

The production web UI is already built in `dist/`. Running the server creates a fresh `data/` directory. No user data or passwords are shipped.

For development use `npm run dev` and http://localhost:5173. Rebuild changed web source with `npm run build`.

## Phone or foldable browser

Use the computer's current LAN IPv4 address with port 3001 on the same network, keeping the server running. Do not use localhost on the phone. The installation-specific LAN address in README is an example, not a packaged service address. Local mode discovers the server computer's IPv4 interfaces at startup; restart after switching networks. See README for firewall and network-isolation troubleshooting.

For ongoing or public use, deploy behind HTTPS and set APP_ORIGIN to the exact public origin. Docker Compose's default port binding is local-only for use with a reverse proxy. No service has been published by this release.

## Optional browser notifications

After creating your account:

```sh
npm run push:setup -- mailto:you@your-domain.com
```

Restart TaDa, open the notification bell, select Enable browser push and allow notifications. Keep the generated `.env` private and backed up. Phone push requires HTTPS. The package contains no push keys.

## Android preview

`artifacts/TaDa-v0.1.0-android-debug.apk` is a debug-signed, unconfigured wrapper for build evaluation. It will not connect to a backend by itself. For a connected Android build, deploy TaDa over HTTPS and run:

```powershell
$env:TADA_SERVER_URL='https://your-tada-domain.example'
npm run android:sync
npx cap open android
```

Build using Android Studio/JDK 21/SDK 35. Configure your own signing for distribution. Native background push and offline mode are not included.

## Verify and test

`release-manifest.json` contains SHA-256 hashes of all packaged payload files. `SHA256SUMS.txt` beside the download contains hashes for the release ZIP, APK and release notes.

Run `npm test` for isolated API/worker tests. Read README for browser test commands and operational limits. Browser tests add temporary test accounts to whichever running server they target.
